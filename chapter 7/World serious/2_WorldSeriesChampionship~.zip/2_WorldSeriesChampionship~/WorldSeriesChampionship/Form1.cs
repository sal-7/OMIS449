﻿//OMIS 449					        Spring 2019

//Programmer: Faisal Alharbi,		Z-ID 1748509
//Programmer: Bryce Frank, 		    Z-ID 1733433

//Programming Problem Chapter 7 Exercises #5: World Series Champions
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorldSeriesChampionship
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBrowseTeam_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Filter = "Text|*.txt|All|*.*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(fdlg.FileName);
                lstTems.Items.Clear();
                lstTems.Items.AddRange(lines);
            }
        }

        private void btnBrowseWinners_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Filter = "Text|*.txt|All|*.*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(fdlg.FileName);
                lstWinners.Items.Clear();
                lstWinners.Items.AddRange(lines);
            }
        }

        private void lstTems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstTems.SelectedItem != null)
            {
                List<string> items = lstWinners.Items.Cast<String>().ToList();
                MessageBox.Show(lstTems.SelectedItem.ToString() + " has won the world series " + items.FindAll(f=>f.Contains(lstTems.SelectedItem.ToString())).Count + " times in the time period from 1903 through 2012.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
