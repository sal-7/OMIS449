﻿namespace WorldSeriesChampionship
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstTems = new System.Windows.Forms.ListBox();
            this.btnBrowseTeam = new System.Windows.Forms.Button();
            this.lstWinners = new System.Windows.Forms.ListBox();
            this.btnBrowseWinners = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstTems
            // 
            this.lstTems.FormattingEnabled = true;
            this.lstTems.ItemHeight = 25;
            this.lstTems.Location = new System.Drawing.Point(68, 100);
            this.lstTems.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.lstTems.Name = "lstTems";
            this.lstTems.Size = new System.Drawing.Size(518, 729);
            this.lstTems.TabIndex = 0;
            this.lstTems.SelectedIndexChanged += new System.EventHandler(this.lstTems_SelectedIndexChanged);
            // 
            // btnBrowseTeam
            // 
            this.btnBrowseTeam.Location = new System.Drawing.Point(68, 44);
            this.btnBrowseTeam.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnBrowseTeam.Name = "btnBrowseTeam";
            this.btnBrowseTeam.Size = new System.Drawing.Size(522, 44);
            this.btnBrowseTeam.TabIndex = 1;
            this.btnBrowseTeam.Text = "Browse Teams";
            this.btnBrowseTeam.UseVisualStyleBackColor = true;
            this.btnBrowseTeam.Click += new System.EventHandler(this.btnBrowseTeam_Click);
            // 
            // lstWinners
            // 
            this.lstWinners.FormattingEnabled = true;
            this.lstWinners.ItemHeight = 25;
            this.lstWinners.Location = new System.Drawing.Point(712, 100);
            this.lstWinners.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.lstWinners.Name = "lstWinners";
            this.lstWinners.Size = new System.Drawing.Size(518, 729);
            this.lstWinners.TabIndex = 0;
            // 
            // btnBrowseWinners
            // 
            this.btnBrowseWinners.Location = new System.Drawing.Point(712, 44);
            this.btnBrowseWinners.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnBrowseWinners.Name = "btnBrowseWinners";
            this.btnBrowseWinners.Size = new System.Drawing.Size(522, 44);
            this.btnBrowseWinners.TabIndex = 1;
            this.btnBrowseWinners.Text = "Browse Winners";
            this.btnBrowseWinners.UseVisualStyleBackColor = true;
            this.btnBrowseWinners.Click += new System.EventHandler(this.btnBrowseWinners_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1310, 900);
            this.Controls.Add(this.btnBrowseWinners);
            this.Controls.Add(this.btnBrowseTeam);
            this.Controls.Add(this.lstWinners);
            this.Controls.Add(this.lstTems);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Championship winners";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstTems;
        private System.Windows.Forms.Button btnBrowseTeam;
        private System.Windows.Forms.ListBox lstWinners;
        private System.Windows.Forms.Button btnBrowseWinners;
    }
}

