﻿namespace PopularNames
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstBoys = new System.Windows.Forms.ListBox();
            this.lstGirls = new System.Windows.Forms.ListBox();
            this.btnBrowseBoys = new System.Windows.Forms.Button();
            this.btnBrowseGirls = new System.Windows.Forms.Button();
            this.txtBoyName = new System.Windows.Forms.TextBox();
            this.btnFindBoy = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtGirlName = new System.Windows.Forms.TextBox();
            this.btnFindGirl = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstBoys
            // 
            this.lstBoys.FormattingEnabled = true;
            this.lstBoys.ItemHeight = 25;
            this.lstBoys.Location = new System.Drawing.Point(112, 269);
            this.lstBoys.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.lstBoys.Name = "lstBoys";
            this.lstBoys.Size = new System.Drawing.Size(534, 604);
            this.lstBoys.TabIndex = 0;
            // 
            // lstGirls
            // 
            this.lstGirls.FormattingEnabled = true;
            this.lstGirls.ItemHeight = 25;
            this.lstGirls.Location = new System.Drawing.Point(732, 269);
            this.lstGirls.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.lstGirls.Name = "lstGirls";
            this.lstGirls.Size = new System.Drawing.Size(534, 604);
            this.lstGirls.TabIndex = 0;
            // 
            // btnBrowseBoys
            // 
            this.btnBrowseBoys.Location = new System.Drawing.Point(112, 213);
            this.btnBrowseBoys.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnBrowseBoys.Name = "btnBrowseBoys";
            this.btnBrowseBoys.Size = new System.Drawing.Size(538, 44);
            this.btnBrowseBoys.TabIndex = 1;
            this.btnBrowseBoys.Text = "Browse Boys";
            this.btnBrowseBoys.UseVisualStyleBackColor = true;
            this.btnBrowseBoys.Click += new System.EventHandler(this.btnBrowseBoys_Click);
            // 
            // btnBrowseGirls
            // 
            this.btnBrowseGirls.Location = new System.Drawing.Point(732, 213);
            this.btnBrowseGirls.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnBrowseGirls.Name = "btnBrowseGirls";
            this.btnBrowseGirls.Size = new System.Drawing.Size(538, 44);
            this.btnBrowseGirls.TabIndex = 1;
            this.btnBrowseGirls.Text = "Browse Girls";
            this.btnBrowseGirls.UseVisualStyleBackColor = true;
            this.btnBrowseGirls.Click += new System.EventHandler(this.btnBrowseGirls_Click);
            // 
            // txtBoyName
            // 
            this.txtBoyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoyName.Location = new System.Drawing.Point(112, 106);
            this.txtBoyName.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtBoyName.Name = "txtBoyName";
            this.txtBoyName.Size = new System.Drawing.Size(368, 44);
            this.txtBoyName.TabIndex = 2;
            // 
            // btnFindBoy
            // 
            this.btnFindBoy.Location = new System.Drawing.Point(500, 110);
            this.btnFindBoy.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnFindBoy.Name = "btnFindBoy";
            this.btnFindBoy.Size = new System.Drawing.Size(150, 44);
            this.btnFindBoy.TabIndex = 3;
            this.btnFindBoy.Text = "Find";
            this.btnFindBoy.UseVisualStyleBackColor = true;
            this.btnFindBoy.Click += new System.EventHandler(this.btnFindBoy_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 69);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Boy Name";
            // 
            // txtGirlName
            // 
            this.txtGirlName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGirlName.Location = new System.Drawing.Point(732, 110);
            this.txtGirlName.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtGirlName.Name = "txtGirlName";
            this.txtGirlName.Size = new System.Drawing.Size(368, 44);
            this.txtGirlName.TabIndex = 2;
            // 
            // btnFindGirl
            // 
            this.btnFindGirl.Location = new System.Drawing.Point(1120, 113);
            this.btnFindGirl.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnFindGirl.Name = "btnFindGirl";
            this.btnFindGirl.Size = new System.Drawing.Size(150, 44);
            this.btnFindGirl.TabIndex = 3;
            this.btnFindGirl.Text = "Find";
            this.btnFindGirl.UseVisualStyleBackColor = true;
            this.btnFindGirl.Click += new System.EventHandler(this.btnFindGirl_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(732, 73);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Girl Name";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1384, 946);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFindGirl);
            this.Controls.Add(this.btnFindBoy);
            this.Controls.Add(this.txtGirlName);
            this.Controls.Add(this.txtBoyName);
            this.Controls.Add(this.btnBrowseGirls);
            this.Controls.Add(this.btnBrowseBoys);
            this.Controls.Add(this.lstGirls);
            this.Controls.Add(this.lstBoys);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Popular NAmes";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox lstBoys;
        private System.Windows.Forms.ListBox lstGirls;
        private System.Windows.Forms.Button btnBrowseBoys;
        private System.Windows.Forms.Button btnBrowseGirls;
        private System.Windows.Forms.TextBox txtBoyName;
        private System.Windows.Forms.Button btnFindBoy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtGirlName;
        private System.Windows.Forms.Button btnFindGirl;
        private System.Windows.Forms.Label label2;
    }
}

