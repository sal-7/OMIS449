﻿//OMIS 449					        Spring 2019

//Programmer: Faisal Alharbi,		Z-ID 1748509
//Programmer: Bryce Frank, 		    Z-ID 1733433

//Programming Problem Chapter 7 Exercises #6: Name Search
using System;
using System.IO;
using System.Windows.Forms;

namespace PopularNames
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFindBoy_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBoyName.Text))
            {
                MessageBox.Show(lstBoys.Items.Contains(txtBoyName.Text) ? "This boy is among most popular list." : "This boy is not popular.");
            }
        }

        private void btnFindGirl_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtGirlName.Text))
            {
                MessageBox.Show(lstGirls.Items.Contains(txtGirlName.Text) ? "This girl is among most popular list." : "This girl is not popular.");
            }
        }

        private void btnBrowseBoys_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Filter = "Text|*.txt|All|*.*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(fdlg.FileName);
                lstBoys.Items.Clear();
                lstBoys.Items.AddRange(lines);
            }
        }

        private void btnBrowseGirls_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Filter = "Text|*.txt|All|*.*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(fdlg.FileName);
                lstGirls.Items.Clear();
                lstGirls.Items.AddRange(lines);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
